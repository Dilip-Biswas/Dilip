var cities = [
				// GeoJSON to parse in Infobox of Marker
              {
                  place : 'Sevilla',
				  img:'img/a.jpg',
                  desc : 'Sevilla ist die Hauptstadt der Autonomen Region Andalusien und der Provinz Sevilla von Spanien.', 
                  lat : 37.3826399917813,
                  long : -5.996295000208264
              },
			  {
                  place : 'Granada',
				  img:'img/b.jpg',
                  desc : 'Wirtschaftliche und kulturelle Stadt, die Universitaet Granada von grosser Bedeutung.',
                  lat : 37.17648700163939,
                  long : -3.597929001227509
              },
			  {
                  place : 'Sierra Nevada',
				  img:'img/c.jpg',
                  desc : 'Die Sierra Nevada zieht sich in westoestlicher Richtung an einem Teil der suedlichen Mittelmeerkueste Spaniens entlang',
                  lat : 37.06666700202622,
                  long : -3.366667001788221
              },
              {
                  place : 'Malaga',
				  img:'img/d.jpg',
                  desc : 'Die Provinz Malaga ist eine der suedlichen unter den acht Provinzen der autonomen Region Andalusien in Suedspanien.',
                  lat : 36.7196459872271,
                  long : -4.420018997067069
			  },
              {
                  place : 'Gibraltar',
				  img:'img/e.jpg',
                  desc : 'Gibraltar ist ein britisches Ueberseegebiet an der Suedspitze der Iberischen Halbinsel.',
                  lat : 36.14623962089493,
                  long : -5.342454310584487
			  },
			  {
                  place : 'Tarifa',
				  img:'img/f.jpg',
                  desc : 'Tarifa ist die am suedlichsten gelegene Stadt des europaeischen Festlands.',
                  lat : 36.0130588118713,
                  long : -5.605873429527972
			  },
			  {
                  place : 'Cadiz',
				  img:'img/g.jpg',
                  desc : 'Cadiz hat 3200 Sonnenstunden im Jahr',
                  lat : 36.52968800327907,
                  long : -6.292656999215195
			  }
          ];

          //Angular App Module and Controller
          var mapApp = angular.module('mapApp', []);
          mapApp.controller('MapController', function ($scope) {
              
              var mapOptions = 
			  {
                  zoom: 7,
                  center: new google.maps.LatLng(37.3826399917813,-5.996295000208264),
				  mapTypeId: google.maps.MapTypeId.ROADMAP
				  
              }

			  			  
              $scope.map = new google.maps.Map(document.getElementById('map'), mapOptions);

              $scope.markers = [];
              
              var infoWindow = new google.maps.InfoWindow();
              
              var createMarker = function (info)
			  {
                  
                  var marker = new google.maps.Marker
				  (
				  {
                      map: $scope.map,
                      position: new google.maps.LatLng(info.lat, info.long),
					  icon:'https://maps.google.com/mapfiles/ms/icons/green-dot.png',
                      title: info.place
					  
                  });
                  marker.content = '<div class="infoWindowContent">' + info.desc + '<br />' + info.lat + ', ' + info.long +  ' </div>';
                  
                  google.maps.event.addListener(marker, 'click', function()
				  {
                      infoWindow.setContent('<h3>' + marker.title + '</h3>' +  marker.content);
                      infoWindow.open($scope.map, marker);
                  });
                  
                  $scope.markers.push(marker);
                  
              }  
              // Function to get the length of GeoJSON
              for (i = 0; i < cities.length; i++)
			  {
                  createMarker(cities[i]);
              }

              $scope.openInfoWindow = function(e, selectedMarker)
			  {
                  e.preventDefault();
                  google.maps.event.trigger(selectedMarker, 'click');
              }  
          });