

	$('.slider').each(function(){//f�r jede slightshow
	
		var $this = $(this);			//ruft die aktuelle slightShow == dieses Objekt
		var $group = $(this).find('.slide-group');	//FINDE die slideGroup
		var $slides = $(this).find('.slide');
		var buttonArray = [];						//array f�r schaltfl�chen
           var timeout;
		var currentIndex = 0;	
		
		function move(newIndex)
		{		//wechselt von der alten zur neuen folie
			var animateLeft, slideLeft;		//variablen deklarieren
			advance();				//bei bewegung des sliders wird diese funktion aufgerufen
			
		//logisch ODER: tue nichts wenn die neue folie die aktuelle ist oder die ani l�uft
		if( $group.is(':animated') || currentIndex === newIndex)
		{
			
			return;					//abbrechen
			}
			buttonArray[currentIndex].removeClass('active');//entfernen beim aktuellen buttonArray
			buttonArray[newIndex].addClass('active');
			
			if(newIndex > currentIndex)
			{
				
				slideLeft = '100%';				//platziere die neue folie rechts
				animateLeft = '-100%';			//animiere die folie nach links
			}
			else
			{
				
				slideLeft = '-100%';				//platziere die neue folie links
				animateLeft = '100%';			//animiere die folie nach rechts
			}
			
			//einf�gen der variablenWerte als css-regel
			//platziert die neue folie..wird sichtbar gemacht 
			//$eq=equal=gleich
			$slides.eq(newIndex).css({left:slideLeft, display:'block'});
			$group.animate({ left:animateLeft},1000,function(){  //animation der leftposition
				
				$slides.eq(currentIndex).css({ display:'none'}); //verbergen der vorherigen folie	
				$slides.eq(newIndex).css({ left:0 });			//position der neune folie
				$group.css({ left:0 });							//position der folienGruppe
				
				currentIndex = newIndex;		//currentIndex wird auf die neue folie gesetzt
			});
			
		}	
		function advance()
		{					//richtet den timer ein
			clearTimeout(timeout);			//l�scht den timer in timeout
			timeout = setTimeout(function()
			{
				if(currentIndex < ( $slides.length-1))
				{
				move( currentIndex +1);		//wechsel zur n�chsten folie
				}
				else
				{
					move(0);				//wechsel zur ersten folie
				}	
			
			},3000);
		}
		
		//erstellen der schaltfl�chen f�r jeden slide in bezug auf den index
		$.each($slides,function(index)
		{
			var $button = $('<button type="button" class="slide-btn">&bull;</button>');
			if(index === currentIndex)
			{		//bei index der aktuellen folie erteile die klasse active
				$button.addClass('active');
			}
			$button.on('click',function()
			{
				move(index);				//ruft bei klick die funktion move auf
				alert(index);
			}).appendTo('.slide-buttons');	//schaltfl�chen anh�ngen
			buttonArray.push($button);		//button dem array durch push() hinzuf�gen
		});
		
		advance();
});