		
		
		var directionsDisplay;
		var directionsService = new google.maps.DirectionsService();
		var directionsDisplay = new google.maps.DirectionsRenderer();
		var map;

		function initialize() 
		{
		directionsDisplay = new google.maps.DirectionsRenderer();
		var Sevilla = new google.maps.LatLng(37.3826399917813,-5.996295000208264);
		var mapOptions = 
		{
		zoom:7,
		center: Sevilla
		}
		map = new google.maps.Map(document.getElementById('map-canvas'), mapOptions);
		directionsDisplay.setMap(map);
		}

		var x = document.getElementById("demo");

		function getLocation() 
		{
		if (navigator.geolocation) 
		{
        navigator.geolocation.getCurrentPosition(showPosition);
		} else 
		{ 
        x.innerHTML = "Geolocation is not supported by this browser.";
		}
		}

		function showPosition(position) 
		{
		x.innerHTML = "Latitude: " + position.coords.latitude + 
		"<br>Longitude: " + position.coords.longitude;	
		}
		
		
		
		
		
		
		
		
		
		
		function calcRoute() 
		{
		var start = document.getElementById('start').value;
		var end = document.getElementById('end').value;
		var request = 
		{
		origin:start,
		destination:end,
		travelMode: google.maps.TravelMode.DRIVING
		};
		directionsService.route(request, function(response, status) 
		{
		if (status == google.maps.DirectionsStatus.OK) 
		{
			directionsDisplay.setDirections(response);
			showMe(response);
		} 
		else 
		{
			alert("This did not work because "+ status);
		}
		});
		}

		function showMe(directionsResult)
		{
		var onlyLeg = directionsResult.routes[0].legs[0];
		var startPointAddress = onlyLeg.start_address;
		var startPointCoords =onlyLeg.start_location;
		var totalDistance =onlyLeg.distance.text;
		'var totalTime=onlyLeg.duration.text;'
		var endPointAddress =onlyLeg.end_address;
		var endPointCoords =onlyLeg.end_location;
		var x=document.getElementById("demo");
		alert("Start Position : " + startPointAddress + startPointCoords + '\n'+ "End Position : " + endPointAddress + endPointCoords + '\n'+ "Total Distance : " + totalDistance);
		};
	
		function getLocation()
		{
		if (navigator.geolocation)
		{
		navigator.geolocation.getCurrentPosition(showPosition);
		}
		else{x.innerHTML="Geolocation is not supported by this browser.";
		}
		}

		function showPosition(position)
		{
		x.innerHTML="Latitude: " + position.coords.latitude + "<br>Longitude: " + position.coords.longitude;	
		}
		google.maps.event.addDomListener(window, 'load', initialize);