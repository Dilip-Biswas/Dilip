		
	var directionDisplay;
	var directionsService = new google.maps.DirectionsService();
	var map;
	var directionDisplay;
	var directionsService = new google.maps.DirectionsService();
	var geocoder = new google.maps.Geocoder();

	function initialize() 
	{
		map = new google.maps.Map(document.getElementById('map'),
		{
			center: new google.maps.LatLng(36.76506952934225,-4.717045528297399),
			zoom: 8,
			mapTypeId: google.maps.MapTypeId.HYBRID
		});
		//Setting Marker in Sevilla
		var marker = new google.maps.Marker
		({
			position: new google.maps.LatLng(37.3826399917813,-5.996295000208264),
			animation:google.maps.Animation.BOUNCE
		});
		marker.setMap(map);
		// JavaScript Example on google API https://developers.google.com/maps/documentation/javascript/examples/
		directionsDisplay = new google.maps.DirectionsRenderer();
		directionsDisplay.setMap(map);
		directionsDisplay.setPanel(document.getElementById("directionsPanel"));
		// PANORAMA OPTION
		var panoramaOptions = 
		{
			position: new google.maps.LatLng(36.76506952934225,-4.717045528297399),
			pov: 
			{
				heading: 250,
				pitch: 0,
				zoom: 8
			}
		};
		var panorama = new  google.maps.StreetViewPanorama(document.getElementById("pano"),panoramaOptions);
		map.setStreetView(panorama);
	}

	function zoomtoaddress()
		{	// Use the geocoder to geocode the address
			geocoder.geocode( { 'address': document.getElementById("address").value }, function(results, status) 
			{
				// If the status of the geocode is OK
			if (status == google.maps.GeocoderStatus.OK) 
			{
				// Change the center and zoom of the map
				map.setCenter(results[0].geometry.location);
				map.setZoom(10); 
			} 
			});
		}
	// Register Enter key press to submit form
	window.onkeypress = enterSubmit;
	function enterSubmit() 
		{
			if(event.keyCode==13) 
				{
				zoomtoaddress();
				}
		}
 
	//DIRECTIONS FUNCTION 
	function calcRoute() 
		{
			var start = document.getElementById("start").value;
			var end = document.getElementById("end").value;
			var selectedMode = document.getElementById("mode").value;
			//above line pasted from mode of travel function
			var request = 
			{
			origin:start, 
			destination:end,
			travelMode: google.maps.DirectionsTravelMode[selectedMode]
			};
			directionsService.route(request, function(response, status) 
			{
			if (status == google.maps.DirectionsStatus.OK) 
				{
				directionsDisplay.setDirections(response);
				}
			});
	
		// Load GeoJSON.
		map.data.loadGeoJson('https://storage.googleapis.com/maps-devrel/google.json');
		// Set the stroke width, and fill color for each polygon
		map.data.setStyle
		({
			fillColor: 'green',
			strokeWeight: 3
		});
	}
	
	
	
	
	
	
	